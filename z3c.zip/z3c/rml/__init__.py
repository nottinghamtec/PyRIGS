# Hook up our custom paragraph parser.
import z3c.rml.paraparser
import z3c.rml.rlfix


from reportlab.lib.styles import getSampleStyleSheet
SampleStyleSheet = getSampleStyleSheet()

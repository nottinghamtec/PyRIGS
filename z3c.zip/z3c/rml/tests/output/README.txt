This directory contains the PDF output of the tests.
